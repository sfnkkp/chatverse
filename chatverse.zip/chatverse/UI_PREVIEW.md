# ChatVerse - UI Preview & Mockups

## 🎨 Visual Design Overview

This document describes what each page looks like in ChatVerse.

---

## 1. Home Page

```
┌────────────────────────────────────────────────────────────┐
│                                                            │
│                    Animated Gradient Background            │
│                   (Purple/Blue/Pink blend)                 │
│                                                            │
│                                                            │
│              ┌──────────────────────────┐                  │
│              │      ChatVerse           │                  │
│              │  (Gradient text logo)    │                  │
│              └──────────────────────────┘                  │
│                    ═══════════                             │
│                   (Blue glow line)                         │
│                                                            │
│                                                            │
│              ┌──────────────────────────┐                  │
│              │   Start Chatting         │                  │
│              │   (Large hero text)      │                  │
│              └──────────────────────────┘                  │
│                                                            │
│         Connect with strangers instantly.                  │
│                                                            │
│                                                            │
│         ┌────────────────────────────┐                     │
│         │  Choose your username      │                     │
│         │  ┌──────────────────────┐  │                     │
│         │  │ [Username input]     │  │  (Glass panel)      │
│         │  └──────────────────────┘  │                     │
│         └────────────────────────────┘                     │
│                                                            │
│              ┌─────────────────┐                           │
│              │ Start Chatting  │  (Glowing blue button)    │
│              └─────────────────┘                           │
│                                                            │
│    ┌───────────┐  ┌───────────┐  ┌───────────┐           │
│    │    ⚡     │  │    🔒     │  │    🌍     │           │
│    │  Instant  │  │ Anonymous │  │  Global   │  (Cards)   │
│    │  Match    │  │           │  │           │           │
│    └───────────┘  └───────────┘  └───────────┘           │
│                                                            │
│              Profile | Admin                              │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

### Home Page Features
- **Animated gradient background** slowly shifting colors
- **Large gradient logo** "ChatVerse" in blue→purple→pink
- **Glass effect panels** with blur and transparency
- **Smooth animations** fade and slide on page load
- **Feature cards** showing key benefits
- **Clean navigation** at bottom

---

## 2. Chat Page (Desktop Layout)

```
┌──────────────────────────────────────────────────────────────────┐
│ Left Sidebar  │      Main Chat Area          │  Right Panel    │
│ (280px)       │      (Flexible)              │  (320px)        │
│               │                               │                 │
│ ┌───────────┐ │ ┌────────────────────────────┐│ ┌─────────────┐│
│ │ChatVerse  │ │ │ Partner Info | [End Chat] ││ │   Avatar    ││
│ └───────────┘ │ └────────────────────────────┘│ │   (Large)   ││
│               │                               │ │ ┌─────────┐ ││
│ ┌───────────┐ │ ┌────────────────────────────┐│ │ │ Online  │ ││
│ │🔍 Find    │ │ │                            ││ │ └─────────┘ ││
│ │New Chat   │ │ │    Message Bubbles         ││ │             ││
│ └───────────┘ │ │                            ││ │ Username    ││
│               │ │  ┌──────────────┐          ││ │             ││
│ ┌───────────┐ │ │  │Partner: Hi! │          ││ │ ┌─────────┐ ││
│ │⚙️ Settings│ │ │  └──────────────┘          ││ │ │User Info│ ││
│ └───────────┘ │ │                            ││ │ │ ・Status │ ││
│               │ │  ┌──────────────┐          ││ │ │ ・Online│ ││
│               │ │  │You: Hello!   │          ││ │ └─────────┘ ││
│ ┌───────────┐ │ │  └──────────────┘          ││ │             ││
│ │Quick Tips │ │ │                            ││ │ [Actions]   ││
│ │• Press    │ │ │  Partner is typing...      ││ │             ││
│ │  Enter    │ │ │                            ││ └─────────────┘│
│ │• Hover to │ │ └────────────────────────────┘│                 │
│ │  react    │ │ ┌────────────────────────────┐│                 │
│ └───────────┘ │ │ [Type a message...] [Send] ││                 │
│               │ └────────────────────────────┘│                 │
└──────────────────────────────────────────────────────────────────┘
```

### Chat Page Features
- **Three-column Discord layout**
- **Glass effect panels** with dark theme
- **Message bubbles** different colors for own/partner
- **Typing indicator** with animated dots
- **Reaction hover** shows emoji picker
- **Partner avatar** with online status ring
- **Smooth scrolling** message area
- **Real-time updates** instant message delivery

---

## 3. Chat Page (Mobile Layout)

```
┌──────────────────────────┐
│ ☰  Partner Info [End]    │ (Header)
├──────────────────────────┤
│                          │
│  ┌─────────────────┐     │
│  │Partner: Hi!     │     │
│  └─────────────────┘     │
│                          │
│     ┌─────────────────┐  │
│     │You: Hello!      │  │
│     └─────────────────┘  │
│                          │
│  Partner is typing...    │
│                          │
│                          │ (Messages)
│                          │
│                          │
│                          │
├──────────────────────────┤
│ [Type a message...] [>]  │ (Input)
└──────────────────────────┘
```

### Mobile Features
- **Collapsed sidebar** accessible via hamburger menu
- **Full-width chat area**
- **Touch-optimized** 44px minimum touch targets
- **Swipe gestures** for navigation
- **Reduced animations** for performance

---

## 4. Profile Page

```
┌────────────────────────────────────────────────────────────┐
│                                                            │
│  Profile Settings                         [← Back to Home] │
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │                                                    │   │
│  │   ┌────────┐         Username                     │   │
│  │   │        │         ┌──────────────────┐         │   │
│  │   │ Avatar │         │ [Enter username] │         │   │
│  │   │  (SVG) │         └──────────────────┘         │   │
│  │   │   🟢   │                                       │   │
│  │   └────────┘         Theme                        │   │
│  │    Generate          ┌────┐ ┌────┐ ┌────┐        │   │
│  │                      │Dark│ │Neon│ │Pur │ (✓)    │   │
│  │                      └────┘ └────┘ └────┘        │   │
│  │                                                    │   │
│  │              [Save Changes] [Go to Chat]          │   │
│  │                                                    │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │  Your Stats                                        │   │
│  │  ┌──────┐  ┌──────┐  ┌──────┐                     │   │
│  │  │  42  │  │ 387  │  │  89  │                     │   │
│  │  │Chats │  │ Msgs │  │Conns │                     │   │
│  │  └──────┘  └──────┘  └──────┘                     │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │  ⚠️ Danger Zone                                    │   │
│  │  [Clear All Data]                                  │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

### Profile Features
- **Large avatar display** with online indicator
- **Regenerate button** for new avatar
- **Theme selector** with visual preview
- **Stats cards** with gradient numbers
- **Save confirmation** animated feedback
- **Danger zone** warning styling

---

## 5. Admin Dashboard

```
┌────────────────────────────────────────────────────────────┐
│  Admin Dashboard                          [Home] [Logout]  │
│  Real-time monitoring and management                       │
│                                                            │
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐                  │
│  │  24  │  │  12  │  │   3  │  │   0  │                  │
│  │Users │  │Chats │  │Queue │  │ Bans │  (Stat Cards)     │
│  └──────┘  └──────┘  └──────┘  └──────┘                  │
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │ Overview │ Users │ Chats │ Logs │  (Tabs)          │   │
│  ├────────────────────────────────────────────────────┤   │
│  │                                                    │   │
│  │  Users Table:                                      │   │
│  │  ┌────────┬──────────┬────────┬────────┬────────┐ │   │
│  │  │Username│SocketID │   IP   │ Status │ Actions│ │   │
│  │  ├────────┼──────────┼────────┼────────┼────────┤ │   │
│  │  │ User1  │ abc123   │192...  │In Chat │[Kick]  │ │   │
│  │  │ User2  │ def456   │192...  │ Idle   │[Ban]   │ │   │
│  │  │ User3  │ ghi789   │192...  │In Chat │[Kick]  │ │   │
│  │  └────────┴──────────┴────────┴────────┴────────┘ │   │
│  │                                                    │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
│  Last updated: 2 seconds ago... Auto-refresh enabled       │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

### Admin Features
- **Real-time stats** with colored indicators
- **Tabbed interface** for organization
- **Data tables** with hover effects
- **Action buttons** (Kick, Ban)
- **Auto-refresh indicator**
- **Responsive layout**
- **Color-coded status** (green=active, yellow=idle)

---

## 6. Admin Login

```
┌────────────────────────────────────────┐
│                                        │
│                                        │
│         ┌──────────────┐               │
│         │ Admin Panel  │               │
│         │   ChatVerse  │               │
│         └──────────────┘               │
│          Management                    │
│                                        │
│         Username                       │
│         ┌──────────────┐               │
│         │  [admin]     │               │
│         └──────────────┘               │
│                                        │
│         Password                       │
│         ┌──────────────┐               │
│         │  [••••••••]  │               │
│         └──────────────┘               │
│                                        │
│         ┌──────────────┐               │
│         │    Login     │ (Blue glow)   │
│         └──────────────┘               │
│                                        │
│         ← Back to Home                 │
│                                        │
└────────────────────────────────────────┘
```

---

## 🎨 Color Scheme

### Primary Colors
```
🔵 Primary Blue:   #00BFFF  ████ (Buttons, links, active)
🟣 Primary Purple: #8A2BE2  ████ (Secondary elements)
🩷 Primary Pink:   #FF00FF  ████ (Accents, highlights)
```

### Backgrounds
```
⬛ Dark 1: #0A0014  ████ (Gradient start)
⬛ Dark 2: #050A18  ████ (Gradient middle)
⬛ Dark 3: #14000A  ████ (Gradient end)
▪️ Glass:  rgba(26,27,38,0.5) ████ (Panels)
```

### Text & Borders
```
⬜ Text Primary:   #E4E4E7  ████ (Main text)
▫️ Text Secondary: #A0A0B0  ████ (Subtle text)
▫️ Border:         #3A3A4A  ████ (Lines, dividers)
```

### Status Colors
```
🟢 Success: #22C55E  ████ (Online, success)
🟡 Warning: #F59E0B  ████ (Warnings)
🔴 Error:   #EF4444  ████ (Errors, bans)
```

---

## ✨ Animation Examples

### Page Load
```
1. Fade in:  0% → 100% opacity (0.4s)
2. Slide up: +20px → 0px (0.4s)
3. Scale in: 0.9 → 1.0 (0.5s)
```

### Button Hover
```
1. Scale: 1.0 → 1.05 (0.25s)
2. Glow: Box-shadow appears
3. Color: Slight brightness increase
```

### Message Send
```
1. Slide in from right (own messages)
2. Slide in from left (partner messages)
3. Fade in: 0% → 100% (0.3s)
```

### Typing Indicator
```
Dots animate up and down in sequence:
Dot 1: ↕️ (0.0s delay)
Dot 2: ↕️ (0.2s delay)
Dot 3: ↕️ (0.4s delay)
Loop: 1.4s cycle
```

---

## 📱 Responsive Breakpoints

### Mobile (< 768px)
- Single column layout
- Sidebar becomes hamburger menu
- Full-width chat area
- Stacked feature cards
- Larger touch targets

### Tablet (768px - 1024px)
- Two column layout
- Sidebar visible
- Right panel hidden (button to show)
- Optimized spacing

### Desktop (> 1024px)
- Three column layout
- All panels visible
- Maximum 1440px width
- Centered on screen

---

## 🎭 Component Styles

### Glass Panel
```css
background: rgba(26, 27, 38, 0.5);
backdrop-filter: blur(24px);
border: 1px solid rgba(255, 255, 255, 0.1);
border-radius: 24px;
box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
```

### Glow Button
```css
background: #00BFFF;
color: white;
padding: 12px 32px;
border-radius: 12px;
transition: all 250ms ease;

:hover {
  transform: scale(1.05);
  box-shadow: 0 0 16px rgba(0, 191, 255, 0.4);
}
```

### Message Bubble
```css
/* Partner message */
background: #1A1B26;
color: #E4E4E7;
border-radius: 12px 12px 12px 4px;

/* Own message */
background: #00BFFF;
color: white;
border-radius: 12px 12px 4px 12px;
```

---

## 🖼️ Visual Hierarchy

```
1. Hero/Logo        (Largest, most prominent)
   ↓
2. Primary CTA      (Glowing, centered)
   ↓
3. Feature Cards    (Supporting info)
   ↓
4. Navigation       (Subtle, bottom)
```

---

Made with ❤️ by MiniMax Agent
